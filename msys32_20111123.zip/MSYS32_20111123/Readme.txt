The MinGW-w64 MSYS package
--------------------------

This is the MinGW-w64 MSYS package. It is nothing more than a (complete) collection of MSYS binaries.

This includes all *-dll, *-bin, *-ext, *-rtm, and *-smp packages found on the MinGW Sourceforge.net website.

Licenses for all these programs can be found in the source package, suffixed with -src.

The source package is found where you should find this package:

mingw-w64.sourceforge.net --> files --> External binary packages --> MSYS

This package is provided with no guarantee whatsoever, in the hope it is useful to anyone else but me.

Author/Packager: rubenvb